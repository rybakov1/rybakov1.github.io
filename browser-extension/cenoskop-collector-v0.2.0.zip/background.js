'use strict';
importScripts('extractor.js', 'collector-engine.js');
const autoCollector = new globalThis.CenoskopCollectorEngine(chrome, globalThis.CenoskopExtractor);
autoCollector.initialize().catch(() => {});
chrome.runtime.onMessage.addListener((message, sender, sendResponse) => {
  if (sender.id !== chrome.runtime.id || sender.tab) {
    sendResponse({ok: false, error: 'Команды доступны только из окна расширения.'});
    return false;
  }
  autoCollector.dispatch(message).then(data => sendResponse({ok: true, data})).catch(error => sendResponse({ok: false, error: error instanceof Error ? error.message : 'Не удалось выполнить команду.'}));
  return true;
});
chrome.alarms.onAlarm.addListener(alarm => { autoCollector.onAlarm(alarm).catch(() => {}); });
chrome.tabs.onUpdated.addListener((id, change, tab) => { autoCollector.onTabUpdated(id, change, tab).catch(() => {}); });
chrome.tabs.onRemoved.addListener(id => { autoCollector.onTabRemoved(id).catch(() => {}); });
chrome.runtime.onStartup.addListener(() => { autoCollector.onBrowserStartup().catch(() => {}); });
chrome.runtime.onInstalled.addListener(() => { autoCollector.onInstalled().catch(() => {}); });

(function (root) {
  'use strict';
  const STATE_KEY = 'autoCollectorState', ALARM_NAME = 'cenoskop-auto-wake';
  const DEFAULTS = {delaySeconds: 12, renderWaitSeconds: 8, pageTimeoutSeconds: 45, maxPages: 50, autoExport: true};
  const STATUSES = new Set(['idle', 'running', 'paused', 'completed', 'stopped', 'blocked']);
  const GRANTS = new Set(['https://ozon.ru/*', 'https://www.ozon.ru/*', 'https://wildberries.ru/*', 'https://www.wildberries.ru/*']);
  const clone = value => JSON.parse(JSON.stringify(value));
  const errorText = error => String(error?.message || error || 'Неизвестная ошибка').slice(0, 240);

  function settings(input = {}) {
    const number = (key, min, max) => {
      const value = Number(input[key] ?? DEFAULTS[key]);
      if (!Number.isFinite(value) || value < min || value > max) throw new Error(`Настройка ${key}: от ${min} до ${max}.`);
      return Math.round(value);
    };
    return {delaySeconds: number('delaySeconds', 5, 300), renderWaitSeconds: number('renderWaitSeconds', 3, 30), pageTimeoutSeconds: number('pageTimeoutSeconds', 15, 90), maxPages: number('maxPages', 1, 200), autoExport: input.autoExport !== false};
  }
  function emptyState(now) {
    return {version: 1, status: 'idle', queue: [], index: 0, activeTabId: null, settings: {...DEFAULTS}, results: [], errors: [], discovered_count: 0, truncated_count: 0, started_at: null, updated_at: new Date(now).toISOString(), next_action_at: null, phase: null, run_id: null, last_export: null};
  }

  class CollectorEngine {
    constructor(browser, extractor, options = {}) {
      this.browser = browser; this.extractor = extractor;
      this.now = options.now || (() => Date.now());
      this.setTimer = options.setTimeout || ((fn, delay) => setTimeout(fn, delay));
      this.clearTimer = options.clearTimeout || (id => clearTimeout(id));
      this.randomId = options.randomId || (() => root.crypto.randomUUID());
      this.serial = Promise.resolve(); this.epoch = 0; this.cached = null; this.owned = new Set(); this.timer = null; this.ready = null;
    }
    _queue(fn) { const result = this.serial.then(fn); this.serial = result.catch(() => {}); return result; }
    _snapshot() { return clone(this.cached); }
    _valid(epoch) { return epoch === this.epoch; }
    async _save(epoch = this.epoch) {
      if (!this._valid(epoch)) return false;
      this.cached.updated_at = new Date(this.now()).toISOString();
      await this.browser.storage.local.set({[STATE_KEY]: clone(this.cached)});
      return this._valid(epoch);
    }
    initialize() {
      if (this.ready) return this.ready;
      this.ready = this._queue(async () => {
        await Promise.resolve(this.browser.storage.local.setAccessLevel?.({accessLevel: 'TRUSTED_CONTEXTS'})).catch(() => {});
        await this._cleanLegacy();
        const stored = (await this.browser.storage.local.get(STATE_KEY))[STATE_KEY];
        this.cached = stored?.version === 1 && STATUSES.has(stored.status) && Array.isArray(stored.queue) && Array.isArray(stored.results) && Array.isArray(stored.errors) ? stored : emptyState(this.now());
        this.cached.settings = settings(this.cached.settings);
        if (this.cached.activeTabId != null) this.owned.add(this.cached.activeTabId);
        if (this.cached.status === 'running') await this._schedule(Date.parse(this.cached.next_action_at || '') || this.now());
        await this._save(); return this._snapshot();
      });
      return this.ready;
    }
    async _cleanLegacy() {
      const stored = await this.browser.storage.local.get(null);
      const keys = Object.keys(stored).filter(key => /^collector/i.test(key));
      if (keys.length) await this.browser.storage.local.remove(keys);
      const grants = await this.browser.permissions.getAll().catch(() => ({origins: []}));
      const unwanted = (grants.origins || []).filter(origin => !GRANTS.has(origin));
      if (unwanted.length) await this.browser.permissions.remove({origins: unwanted}).catch(() => {});
    }
    _interrupt(closeOwn = true) {
      this.epoch += 1;
      if (this.timer != null) this.clearTimer(this.timer);
      this.timer = null;
      this.browser.alarms.clear(ALARM_NAME).catch(() => {});
      const id = this.cached?.activeTabId;
      if (closeOwn && id != null && this.owned.has(id)) this._removeOwned(id).catch(() => {});
      return this.epoch;
    }
    async _removeOwned(id) {
      if (!this.owned.has(id)) return;
      this.owned.delete(id);
      await this.browser.tabs.remove(id).catch(() => {});
    }
    async _cancelWake() {
      if (this.timer != null) this.clearTimer(this.timer);
      this.timer = null;
      await this.browser.alarms.clear(ALARM_NAME).catch(() => {});
    }
    async _schedule(at, epoch = this.epoch) {
      await this._cancelWake();
      if (!this._valid(epoch) || this.cached.status !== 'running') return;
      this.cached.next_action_at = new Date(at).toISOString();
      // Packed Chrome 120 extensions can defer alarms by >=30s. A foreground
      // timer is only an optimization; this alarm survives worker suspension.
      await this.browser.alarms.create(ALARM_NAME, {when: Math.max(this.now() + 30000, at)});
      if (!this._valid(epoch)) return;
      this.timer = this.setTimer(() => { this.timer = null; if (this._valid(epoch)) this.onAlarm({name: ALARM_NAME}).catch(() => {}); }, Math.max(0, at - this.now()));
    }
    _normalizeUrls(input, limit) {
      const values = Array.isArray(input) ? input : String(input || '').split(/\r?\n/);
      const seen = new Set(), queue = []; let truncated = 0;
      for (const value of values.slice(0, 1000)) {
        if (!String(value).trim()) continue;
        const page = this.extractor.supportedPage(String(value).trim());
        if (seen.has(page.url)) continue;
        seen.add(page.url);
        if (queue.length < limit) queue.push({url: page.url, kind: page.mode === 'discovery' ? 'discovery' : 'product', status: 'pending', attempts: 0});
        else truncated += 1;
      }
      if (!queue.length) throw new Error('Добавьте ссылку на товар или поддерживаемую категорию.');
      return {queue, truncated};
    }
    _hasPermission(url) { return this.browser.permissions.contains({origins: [`${new URL(url).origin}/*`]}); }
    dispatch(message) {
      if (!message || typeof message.type !== 'string') return Promise.reject(new Error('Некорректная команда.'));
      const type = message.type;
      if (type === 'AUTO_START' && this.cached?.status === 'running') return Promise.reject(new Error('Сначала приостановите или остановите текущий сбор.'));
      if (type === 'AUTO_RESUME' && this.cached && this.cached.status !== 'paused') return Promise.reject(new Error('Продолжить можно только приостановленный сбор.'));
      const control = ['AUTO_START', 'AUTO_PAUSE', 'AUTO_RESUME', 'AUTO_STOP', 'AUTO_CLEAR'].includes(type);
      const epoch = control ? this._interrupt() : this.epoch;
      return this.initialize().then(() => this._queue(async () => {
        if (control && !this._valid(epoch)) return this._snapshot();
        if (type === 'AUTO_GET_STATE') return this._snapshot();
        if (type === 'AUTO_START') {
          const config = settings(message.settings), normalized = this._normalizeUrls(message.urls, config.maxPages), queue = normalized.queue;
          for (const item of queue) if (!await this._hasPermission(item.url)) throw new Error('Разрешите доступ к маркетплейсам кнопкой «Начать» в окне расширения.');
          if (!this._valid(epoch)) return this._snapshot();
          this.cached = {...emptyState(this.now()), status: 'running', queue, truncated_count: normalized.truncated, settings: config, run_id: this.randomId(), started_at: new Date(this.now()).toISOString(), phase: 'delay'};
          await this._save(epoch); await this._openNext(epoch); return this._snapshot();
        }
        if (type === 'AUTO_PAUSE' || type === 'AUTO_STOP') {
          await this._cancelWake(); await this._resetInFlight();
          this.cached.status = type === 'AUTO_PAUSE' && this.cached.status === 'running' ? 'paused' : type === 'AUTO_STOP' ? 'stopped' : this.cached.status;
          this.cached.next_action_at = null; this.cached.phase = null;
          await this._save(epoch); return this._snapshot();
        }
        if (type === 'AUTO_RESUME') {
          if (this.cached.status !== 'paused') throw new Error('Продолжить можно только приостановленный сбор. После проверки безопасности начните новый запуск вручную.');
          this.cached.status = 'running'; this.cached.phase = 'delay';
          await this._schedule(this.now() + this.cached.settings.delaySeconds * 1000);
          await this._save(epoch); return this._snapshot();
        }
        if (type === 'AUTO_CLEAR') {
          await this._cancelWake(); await this._resetInFlight(); this.cached = emptyState(this.now());
          await this._save(epoch); return this._snapshot();
        }
        if (type === 'AUTO_EXPORT') return this._export(message.saveAs !== false, false, epoch);
        if (type === 'AUTO_CAPTURE_CURRENT') {
          const [tab] = await this.browser.tabs.query({active: true, currentWindow: true});
          if (tab?.id == null || !tab.url) throw new Error('Откройте поддерживаемую страницу товара.');
          const page = this.extractor.supportedPage(tab.url);
          await this._capture(tab.id, {url: page.url, kind: page.mode === 'discovery' ? 'discovery' : 'product'}, epoch, true);
          return this._snapshot();
        }
        throw new Error('Команда не поддерживается.');
      }));
    }
    async _resetInFlight() {
      const item = this.cached.queue[this.cached.index];
      if (item && ['loading', 'waiting'].includes(item.status)) item.status = 'pending';
      const id = this.cached.activeTabId; this.cached.activeTabId = null;
      if (id != null) await this._removeOwned(id);
      delete this.cached.page_deadline_at;
    }
    async _openNext(epoch) {
      if (!this._valid(epoch) || this.cached.status !== 'running') return;
      while (this.cached.index < this.cached.queue.length && ['complete', 'error'].includes(this.cached.queue[this.cached.index].status)) this.cached.index += 1;
      if (this.cached.index >= this.cached.queue.length) return this._complete(epoch);
      const item = this.cached.queue[this.cached.index];
      try {
        this.extractor.supportedPage(item.url);
        if (!await this._hasPermission(item.url)) throw new Error('Нет разрешения читать этот маркетплейс.');
        if (!this._valid(epoch)) return;
        item.status = 'loading'; item.attempts += 1; this.cached.phase = 'loading';
        this.cached.page_deadline_at = new Date(this.now() + this.cached.settings.pageTimeoutSeconds * 1000).toISOString();
        if (!await this._save(epoch)) return;
        const tab = await this.browser.tabs.create({url: item.url, active: false});
        if (tab?.id == null) throw new Error('Браузер не создал вкладку сбора.');
        this.owned.add(tab.id);
        if (!this._valid(epoch)) { await this._removeOwned(tab.id); return; }
        this.cached.activeTabId = tab.id;
        await this._schedule(Date.parse(this.cached.page_deadline_at)); await this._save(epoch);
        const current = await this.browser.tabs.get(tab.id).catch(() => null);
        if (this._valid(epoch) && current?.status === 'complete') await this._loaded(tab.id, current, epoch);
      } catch (error) { if (this._valid(epoch)) await this._fail('load_failed', errorText(error), epoch); }
    }
    async _loaded(id, tab, epoch) {
      if (!this._valid(epoch) || this.cached.status !== 'running' || this.cached.activeTabId !== id || this.cached.phase !== 'loading') return;
      const item = this.cached.queue[this.cached.index]; if (!item) return;
      try {
        if (this.extractor.supportedPage(tab?.url || item.url).url !== item.url) throw new Error('Страница перенаправлена на другой товар или адрес.');
      } catch {
        await this._block(item, 'unexpected_redirect_or_block', 'Страница перенаправлена на неподтверждённый адрес или проверку безопасности. Сбор остановлен.', epoch);
        return;
      }
      item.status = 'waiting'; this.cached.phase = 'settling';
      await this._schedule(Math.min(this.now() + this.cached.settings.renderWaitSeconds * 1000, Date.parse(this.cached.page_deadline_at)));
      await this._save(epoch);
    }
    onTabUpdated(id, change, tab) {
      const epoch = this.epoch;
      return this.initialize().then(() => this._queue(async () => { if (this._valid(epoch) && change.status === 'complete') await this._loaded(id, tab, epoch); }));
    }
    onTabRemoved(id) {
      const epoch = this.epoch;
      return this.initialize().then(() => this._queue(async () => {
        this.owned.delete(id);
        if (this._valid(epoch) && this.cached.status === 'running' && this.cached.activeTabId === id) await this._fail('tab_closed', 'Вкладка сбора была закрыта до завершения.', epoch);
      }));
    }
    onAlarm(alarm) {
      const epoch = this.epoch;
      return this.initialize().then(() => this._queue(async () => {
        if (!this._valid(epoch) || alarm?.name !== ALARM_NAME || this.cached.status !== 'running') return;
        const at = Date.parse(this.cached.next_action_at || '');
        if (Number.isFinite(at) && this.now() < at) { await this._schedule(at); return; }
        if (this.cached.phase === 'delay' || this.cached.activeTabId == null) { await this._openNext(epoch); return; }
        const deadline = Date.parse(this.cached.page_deadline_at || '');
        if (this.cached.phase === 'loading') {
          const tab = await this.browser.tabs.get(this.cached.activeTabId).catch(() => null);
          if (tab?.status === 'complete') { await this._loaded(tab.id, tab, epoch); return; }
          if (!tab || this.now() >= deadline) { await this._fail('page_timeout', 'Страница не загрузилась за отведённое время.', epoch); return; }
          await this._schedule(deadline); return;
        }
        if (this.cached.phase === 'settling') {
          if (this.now() > deadline) { await this._fail('page_timeout', 'Страница не успела подготовить данные.', epoch); return; }
          await this._capture(this.cached.activeTabId, this.cached.queue[this.cached.index], epoch, false);
        }
      }));
    }
    async _runScript(id) {
      const run = async () => {
        await this.browser.scripting.executeScript({target: {tabId: id}, files: ['extractor.js']});
        const result = await this.browser.scripting.executeScript({target: {tabId: id}, func: () => globalThis.CenoskopExtractor.extract(document, location.href)});
        if (!result[0]?.result) throw new Error('Страница не вернула данные извлечения.');
        return result[0].result;
      };
      let timeout;
      try { return await Promise.race([run(), new Promise((_, reject) => { timeout = this.setTimer(() => reject(new Error('Истекло время чтения страницы.')), 10000); })]); }
      finally { if (timeout != null) this.clearTimer(timeout); }
    }
    async _capture(id, item, epoch, manual) {
      try {
        const tab = await this.browser.tabs.get(id);
        if (this.extractor.supportedPage(tab.url).url !== item.url) throw new Error('Открытая страница не соответствует заданию.');
        const capture = await this._runScript(id);
        if (!this._valid(epoch) || (!manual && (this.cached.status !== 'running' || this.cached.activeTabId !== id))) return;
        if (capture.blocked) {
          await this._block(item, 'captcha_or_challenge', 'Проверка безопасности: сбор остановлен без обхода и автоматических повторов.', epoch);
          return;
        }
        if (this.extractor.supportedPage(capture.url || capture.page_url || tab.url).url !== item.url) throw new Error('Извлечённые данные относятся к другому адресу.');
        if (item.kind === 'discovery') {
          const seen = new Set(this.cached.queue.map(row => row.url));
          for (const link of (capture.links || []).slice(0, 1000)) {
            try {
              const page = this.extractor.supportedPage(typeof link === 'string' ? link : link.url);
              if (page.mode === 'discovery' || seen.has(page.url)) continue;
              seen.add(page.url); this.cached.discovered_count = (this.cached.discovered_count || 0) + 1;
              if (this.cached.queue.length < this.cached.settings.maxPages) this.cached.queue.push({url: page.url, kind: 'product', status: 'pending', attempts: 0});
              else this.cached.truncated_count = (this.cached.truncated_count || 0) + 1;
            } catch { /* unrelated links are never opened */ }
          }
        } else {
          if (typeof this.extractor.buildObservation !== 'function') throw new Error('Модуль экспорта не загружен. Перезагрузите расширение.');
          const row = this.extractor.buildObservation(capture, {requested_url: item.url});
          const previous = this.cached.results.findIndex(item => item.source?.url === row.source?.url);
          if (previous >= 0) this.cached.results[previous] = row;
          else if (this.cached.results.length < 200) this.cached.results.push(row);
        }
        if (!this._valid(epoch)) return;
        if (manual) { await this._save(epoch); return; }
        item.status = 'complete'; delete item.error; await this._afterPage(epoch);
      } catch (error) {
        if (!this._valid(epoch)) return;
        if (manual) throw error;
        await this._fail('extraction_failed', errorText(error), epoch);
      }
    }
    async _fail(code, message, epoch) {
      if (!this._valid(epoch)) return;
      const item = this.cached.queue[this.cached.index];
      if (item) { item.status = 'error'; item.error = code; }
      this.cached.errors.push({url: item?.url || null, code, message, occurred_at: new Date(this.now()).toISOString()});
      this.cached.errors = this.cached.errors.slice(-500); await this._afterPage(epoch);
    }
    async _block(item, code, message, epoch) {
      if (!this._valid(epoch)) return;
      this.cached.status = 'blocked'; this.cached.phase = null; this.cached.next_action_at = null;
      this.cached.errors.push({url: item.url, code, message, occurred_at: new Date(this.now()).toISOString()});
      const current = this.cached.queue[this.cached.index];
      if (current?.url === item.url) { current.status = 'error'; current.error = code; }
      await this._cancelWake();
      const ownId = this.cached.activeTabId; this.cached.activeTabId = null;
      if (ownId != null) await this._removeOwned(ownId);
      await this._save(epoch);
    }
    async _afterPage(epoch) {
      const id = this.cached.activeTabId; this.cached.activeTabId = null;
      if (id != null) await this._removeOwned(id);
      if (!this._valid(epoch)) return;
      this.cached.index += 1; delete this.cached.page_deadline_at;
      if (this.cached.index >= this.cached.queue.length) { await this._complete(epoch); return; }
      this.cached.phase = 'delay';
      await this._schedule(this.now() + this.cached.settings.delaySeconds * 1000); await this._save(epoch);
    }
    async _complete(epoch) {
      if (!this._valid(epoch) || this.cached.status !== 'running') return;
      await this._cancelWake();
      if (!this._valid(epoch) || this.cached.status !== 'running') return;
      this.cached.status = 'completed'; this.cached.phase = null; this.cached.next_action_at = null; this.cached.activeTabId = null;
      if (!await this._save(epoch) || !this._valid(epoch) || this.cached.status !== 'completed') return;
      if (this.cached.settings.autoExport && this.cached.auto_export_attempted_run_id !== this.cached.run_id) await this._export(false, true, epoch);
    }
    async _export(saveAs, automatic, epoch) {
      if (!this._valid(epoch) || (automatic && this.cached.status !== 'completed')) return {cancelled: true};
      if (!this.cached.run_id && !this.cached.results.length) throw new Error('Пока нет результатов для выгрузки.');
      const iso = new Date(this.now()).toISOString();
      const filename = `cenoskop-${iso.slice(0, 10).replace(/-/g, '')}-${iso.slice(11, 19).replace(/:/g, '')}.json`;
      const state = this._snapshot();
      const content = {schema_version: 'cenoskop.browser-export.v1', job: {run_id: state.run_id, status: state.status, partial: state.status !== 'completed', started_at: state.started_at, updated_at: state.updated_at, exported_at: iso, settings: state.settings, queue: state.queue.map(row => ({url: row.url, kind: row.kind, status: row.status, attempts: row.attempts})), processed_pages: state.queue.filter(row => ['complete', 'error'].includes(row.status)).length, discovered_count: state.discovered_count || 0, truncated_count: state.truncated_count || 0}, observations: state.results, errors: state.errors};
      if (automatic) {
        // At most one automatic attempt per run across worker restarts. Manual
        // JSON export remains available if a browser stops during this attempt.
        this.cached.auto_export_attempted_run_id = this.cached.run_id;
        this.cached.last_export = {filename, exported_at: iso};
        if (!await this._save(epoch)) return {cancelled: true};
      }
      if (!this._valid(epoch) || (automatic && this.cached.status !== 'completed')) return {cancelled: true};
      try {
        const id = await this.browser.downloads.download({url: `data:application/json;charset=utf-8,${encodeURIComponent(JSON.stringify(content, null, 2))}`, filename, saveAs});
        if (this._valid(epoch)) { this.cached.last_export = {download_id: id, exported_at: iso, filename}; await this._save(epoch); }
        return {download_id: id, filename, observation_count: state.results.length, state_snapshot: {status: state.status, partial: state.status !== 'completed', updated_at: state.updated_at}};
      } catch (error) {
        if (this._valid(epoch)) { this.cached.last_export = {exported_at: iso, filename, error: errorText(error)}; await this._save(epoch); }
        if (!automatic) throw error;
        return {error: errorText(error), filename, observation_count: state.results.length};
      }
    }
    onBrowserStartup() {
      // A browser restart can reuse tab IDs. Never close a tab solely using the
      // prior session's saved ID; the user explicitly resumes the paused run.
      const epoch = this._interrupt(false);
      return this.initialize().then(() => this._queue(async () => {
        await this._cancelWake(); this.owned.clear();
        if (this.cached.status === 'running') this.cached.status = 'paused';
        const item = this.cached.queue[this.cached.index];
        if (item && ['loading', 'waiting'].includes(item.status)) item.status = 'pending';
        this.cached.activeTabId = null; this.cached.phase = null; this.cached.next_action_at = null; delete this.cached.page_deadline_at;
        await this._save(epoch); return this._snapshot();
      }));
    }
    onInstalled() {
      const epoch = this._interrupt();
      return this.initialize().then(() => this._queue(async () => {
        await this._cleanLegacy(); await this._cancelWake(); await this._resetInFlight();
        if (this.cached.status === 'running') this.cached.status = 'paused';
        this.cached.next_action_at = null; this.cached.phase = null;
        await this._save(epoch); return this._snapshot();
      }));
    }
  }
  root.CenoskopCollectorEngine = CollectorEngine;
  if (typeof module !== 'undefined' && module.exports) module.exports = {CollectorEngine, STATE_KEY, ALARM_NAME, DEFAULTS};
})(typeof globalThis === 'undefined' ? self : globalThis);

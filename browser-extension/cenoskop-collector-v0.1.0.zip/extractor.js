(function (root) {
  'use strict';
  const VERSION = '0.1.0';
  function marketplacePage(value) {
    let url;
    try {url=new URL(value);} catch {throw new Error('Некорректный адрес страницы.');}
    if(url.protocol!=='https:'||url.username||url.password||url.port||/[\\\x00-\x20]/.test(String(value)))throw new Error('Нужна HTTPS-карточка товара Ozon или Wildberries.');
    const host=url.hostname.toLowerCase();
    let marketplace,match;
    if(['ozon.ru','www.ozon.ru'].includes(host)&&(match=url.pathname.match(/^\/product\/(?:[a-zA-Z0-9_-]+-)?([0-9]{1,20})\/?$/)))marketplace='ozon';
    if(['wildberries.ru','www.wildberries.ru'].includes(host)&&(match=url.pathname.match(/^\/catalog\/([0-9]{1,20})\/detail\.aspx$/)))marketplace='wildberries';
    if(!marketplace)throw new Error('Поддерживается только конкретная карточка Ozon /product/…-123/ или Wildberries /catalog/123/detail.aspx.');
    const canonical=marketplace==='ozon'?`https://www.ozon.ru/product/${match[1]}/`:`https://www.wildberries.ru/catalog/${match[1]}/detail.aspx`;
    return {url:canonical,marketplace};
  }
  function apiOrigin(value) {
    let url;
    try {url=new URL(value);} catch {throw new Error('Укажите адрес вашего API.');}
    if(url.username||url.password||url.search||url.hash||!['','/'].includes(url.pathname))throw new Error('Укажите только origin API, без пути, пароля и параметров.');
    if(url.protocol!=='https:'&&!(url.protocol==='http:'&&['localhost','127.0.0.1'].includes(url.hostname)))throw new Error('Для внешнего API нужен HTTPS; HTTP допустим только для localhost и 127.0.0.1.');
    if(/(^|\.)(ozon\.ru|wildberries\.ru)$/.test(url.hostname))throw new Error('API должен принадлежать вам, а не маркетплейсу.');
    return url.origin;
  }
  function marketplaceCategory(value){
    let url;try{url=new URL(value);}catch{throw new Error('Некорректный адрес категории.');}
    if(url.protocol!=='https:'||url.username||url.password||url.port||!['ozon.ru','www.ozon.ru'].includes(url.hostname)||!/^\/category\/[^/]+-\d+\/?$/.test(url.pathname))throw new Error('Категории: поддерживается открытая страница Ozon /category/…-123/.');
    url.search='';url.hash='';return {url:url.href,marketplace:'ozon'};
  }
  function supportedPage(value){try{return {...marketplacePage(value),mode:'product'};}catch{return {...marketplaceCategory(value),mode:'discovery'};}}
  function parsePrice(value) {
    if(typeof value==='number')return Number.isFinite(value)&&value>0&&value<=100000000?value:null;
    if(typeof value!=='string')return null;
    const text=value.trim().replace(/[\u00a0\u202f\s]/g,'').replace(/(?:₽|руб\.?|RUB)$/i,'');
    // Mixed decimal/group separators are ambiguous and must be entered by hand.
    if(!/^\d+(?:[.,]\d{1,2})?$/.test(text))return null;
    const price=Number(text.replace(',','.'));
    return Number.isFinite(price)&&price>0&&price<=100000000?price:null;
  }
  function hasType(node,name){return [node?.['@type']].flat().some(type=>String(type).split(/[\/#]/).pop()===name);}
  function entityName(entity){return typeof entity==='string'?entity:(typeof entity?.name==='string'?entity.name:'');}
  function jsonldProducts(value) {
    const found=[];
    function walk(node,depth=0){
      if(!node||typeof node!=='object'||depth>12)return;
      if(Array.isArray(node)){node.slice(0,150).forEach(item=>walk(item,depth+1));return;}
      if(hasType(node,'Product'))found.push(node);
      if(node['@graph'])walk(node['@graph'],depth+1);
      if(node.mainEntity)walk(node.mainEntity,depth+1);
      if(node.itemListElement)walk(node.itemListElement,depth+1);
      if(node.item)walk(node.item,depth+1);
    }
    walk(value);return found;
  }
  function parseJSONLD(value) {
    const products=jsonldProducts(value),candidates=[];
    for(const product of products){
      function offers(value){
        for(const offer of [value].flat()){
          if(!offer||typeof offer!=='object')continue;
          // AggregateOffer lowPrice/highPrice is not a concrete purchase price.
          if(hasType(offer,'AggregateOffer')){if(offer.offers)offers(offer.offers);continue;}
          if(offer.offers)offers(offer.offers);
          const price=parsePrice(offer.price);
          const currency=String(offer.priceCurrency||'').toUpperCase();
          if(price===null||!currency||(!hasType(offer,'Offer')&&!Object.hasOwn(offer,'price')))continue;
          const seller=offer.seller||product.seller;
          const rawSellerId=typeof seller==='object'?(seller?.identifier||seller?.['@id']||''):'';
          const availability=String(offer.availability||'').split(/[\/#]/).pop();
          candidates.push({price,currency,raw:String(offer.price).slice(0,120),method:'jsonld',label:'JSON-LD Offer',seller_name:entityName(seller).slice(0,150),seller_id:typeof rawSellerId==='string'&&rawSellerId.length<=100?rawSellerId:'',availability:['InStock','LimitedAvailability','OnlineOnly'].includes(availability)?true:['OutOfStock','SoldOut','Discontinued'].includes(availability)?false:null,product_name:entityName(product.name),brand:entityName(product.brand),model:typeof product.model==='string'?product.model:'',mpn:typeof product.mpn==='string'?product.mpn:'',sku:typeof product.sku==='string'?product.sku:''});
        }
      }
      offers(product.offers);
    }
    return candidates;
  }
  function extract(document,pageUrl) {
    const page=supportedPage(pageUrl);
    const bodyText=(document.body?.innerText||'').slice(0,5000);
    const blocked=/провер(?:яем|ка|ьте).{0,35}(?:человек|безопасност)|подтвердите.{0,35}не робот|captcha|access denied|доступ.{0,15}ограничен/i.test(`${document.title||''} ${bodyText}`);
    if(blocked)return {...page,blocked:true,title:document.title||'',candidates:[],captured_at:new Date().toISOString(),extractor_version:VERSION};
    if(page.mode==='discovery'){
      const links=[],seen=new Set();
      for(const anchor of [...document.querySelectorAll('a[href]')].slice(0,5000)){
        if(!anchor.getClientRects().length)continue;
        try{const product=marketplacePage(new URL(anchor.getAttribute('href'),page.url).href);if(product.marketplace!==page.marketplace||seen.has(product.url))continue;seen.add(product.url);links.push({url:product.url,title:(anchor.innerText||anchor.getAttribute('aria-label')||anchor.getAttribute('title')||'Карточка товара').replace(/\s+/g,' ').trim().slice(0,180)});if(links.length===30)break;}catch{/* Non-product links are ignored. */}
      }
      return {...page,blocked:false,title:document.title||'',links,candidates:[],captured_at:new Date().toISOString(),extractor_version:VERSION};
    }
    const candidates=[];
    for(const script of [...document.querySelectorAll('script[type="application/ld+json"]')].slice(0,30)){
      const content=script.textContent||'';if(content.length>1500000)continue;
      try{candidates.push(...parseJSONLD(JSON.parse(content)));}catch{/* Malformed JSON-LD is ignored, not executed. */}
    }
    const selector='[data-widget*="price"],[data-testid*="price"],[class*="price"],[class*="Price"],[itemprop="price"]';
    const nodes=[...document.querySelectorAll(selector)].slice(0,1500);
    // Visible, short text only. Never read cookies, network requests or private app stores.
    for(const node of nodes){
      const style=document.defaultView?.getComputedStyle(node);
      if(!node.getClientRects().length||style?.display==='none'||style?.visibility==='hidden'||node.closest('del,s,[aria-hidden="true"]'))continue;
      const text=(node.innerText||'').replace(/\s+/g,' ').trim();
      if(!text||text.length>180)continue;
      const matches=[...text.matchAll(/\d[\d \u00a0\u202f]*(?:[.,]\d{1,2})?\s*(?:₽|руб\.?|RUB)/gi)];
      for(const match of matches.slice(0,5)){
        const price=parsePrice(match[0]);if(price===null)continue;
        candidates.push({price,currency:'RUB',raw:match[0].slice(0,120),method:'dom',label:text.slice(0,120),seller_name:'',seller_id:'',availability:null});
      }
    }
    const specifications={};
    for(const term of [...document.querySelectorAll('dl dt')].slice(0,120)){
      const key=(term.innerText||'').replace(/\s+/g,' ').trim();let description=term.nextElementSibling;
      if(description?.tagName!=='DD')description=term.parentElement?.querySelector('dd');
      const value=(description?.innerText||'').replace(/\s+/g,' ').trim();
      if(key&&value&&key.length<=80&&value.length<=200&&/партномер|артикул производителя|комплектац|гаранти|объ[её]м|состоян/i.test(key))specifications[key]=value;
    }
    let seller_name='',seller_id='';
    for(const node of [...document.querySelectorAll('a[href*="/seller/"]')].slice(0,20)){
      if(!node.getClientRects().length)continue;
      try{const sellerUrl=new URL(node.href,page.url);if(sellerUrl.hostname.replace(/^www\./,'')!==new URL(page.url).hostname.replace(/^www\./,''))continue;const name=(node.innerText||'').trim();if(name&&name.length<=150){seller_name=name;seller_id=sellerUrl.pathname.slice(0,100);break;}}catch{/* Ignore malformed links. */}
    }
    const unique=[];const seen=new Set();
    for(const candidate of candidates){const key=`${candidate.price}|${candidate.currency}|${candidate.method}|${candidate.seller_name}`;if(seen.has(key))continue;seen.add(key);unique.push({...candidate,seller_name:candidate.seller_name||seller_name,seller_id:candidate.seller_id||seller_id});if(unique.length===30)break;}
    return {...page,blocked:false,title:document.title||'',candidates:unique,specifications,captured_at:new Date().toISOString(),extractor_version:VERSION};
  }
  const api={VERSION,marketplacePage,marketplaceCategory,supportedPage,apiOrigin,parsePrice,parseJSONLD,extract};
  root.CenoskopExtractor=api;
  if(typeof module!=='undefined'&&module.exports)module.exports=api;
})(globalThis);

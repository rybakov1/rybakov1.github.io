'use strict';
const $=id=>document.getElementById(id),parser=globalThis.CenoskopExtractor;
let currentState=null,products=[],capture=null,selectedCandidate=null;
async function message(type,extra={}){const result=await chrome.runtime.sendMessage({type,...extra});if(!result?.ok)throw new Error(result?.error||'Нет ответа от расширения.');return result.data;}
function status(text,kind=''){const box=$('status');box.textContent=text;box.className=kind;box.hidden=!text;}
async function run(work){document.querySelectorAll('button').forEach(button=>button.disabled=true);try{return await work();}catch(error){status(error instanceof Error?error.message:'Неизвестная ошибка','error');return null;}finally{document.querySelectorAll('button').forEach(button=>button.disabled=false);syncJobButtons();}}
function syncJobButtons(){const active=Boolean(currentState?.job&&Date.parse(currentState.job.lease_expires_at)>Date.now());$('openJob').disabled=!active;$('failJob').disabled=!active;}
function renderState(state){
  currentState=state;$('apiOrigin').value=state.settings.apiOrigin;$('token').value=state.settings.token;$('permissionReference').value=state.settings.permissionReference;
  $('workerId').textContent=state.worker_id;$('connectionLabel').textContent=state.settings.token?'ключ сохранён':'не настроено';$('settingsPanel').open=!state.settings.token;
  $('observationPermission').value=state.job?.permission_reference||state.settings.permissionReference;
  $('jobLabel').textContent=state.job?`аренда до ${new Date(state.job.lease_expires_at).toLocaleTimeString('ru-RU')}`:'нет задания';
  $('jobInfo').hidden=!state.job;
  if(state.job){$('jobInfo').textContent=`${state.job.product.name}\n${state.job.url}`;if(!products.some(product=>product.id===state.job.product_id))products.push({...state.job.product,id:state.job.product_id});renderProducts(state.job.product_id);}
  $('useJobLabel').hidden=!state.job;$('useJob').checked=false;syncJobButtons();
}
function renderProducts(preferred=$('productId').value){
  const select=$('productId');select.replaceChildren(new Option('Выберите точную модель',''));
  for(const product of products)select.add(new Option(`${product.name} · ${product.mpn||'MPN неизвестен'}`,product.id));
  if(products.some(product=>product.id===preferred))select.value=preferred;renderCanonical();
}
function renderCanonical(){
  const product=products.find(item=>item.id===$('productId').value);$('canonicalInfo').hidden=!product;$('identityConfirmed').checked=false;
  if(product)$('canonicalInfo').textContent=`${product.brand} · ${product.model}\nMPN: ${product.mpn||'не указан'} · Объём: ${product.capacity} · Комплект: ${product.bundle} · Состояние: ${product.condition}`;
}
function selectCandidate(){
  const index=$('candidate').value;selectedCandidate=index!==''?capture?.candidates[Number(index)]:null;
  if(selectedCandidate){
    $('price').value=String(selectedCandidate.price);$('currency').value=selectedCandidate.currency==='RUB'?'RUB':'';
    $('sellerName').value=selectedCandidate.seller_name||'';$('sellerId').value=selectedCandidate.seller_id||'';
    $('availability').value=selectedCandidate.availability===null?'':String(selectedCandidate.availability);
    $('candidateHint').textContent=`${selectedCandidate.method==='jsonld'?'JSON-LD Offer':'Видимый текст'} · ${selectedCandidate.label}. Условия оплаты и регион не определяются по этой цене: проверьте их отдельно.`;
    const identity=[selectedCandidate.product_name,selectedCandidate.brand&&`Бренд: ${selectedCandidate.brand}`,selectedCandidate.model&&`Модель: ${selectedCandidate.model}`,selectedCandidate.mpn&&`MPN: ${selectedCandidate.mpn}`,selectedCandidate.sku&&`SKU площадки: ${selectedCandidate.sku}`,...Object.entries(capture?.specifications||{}).map(([key,value])=>`${key}: ${value}`)].filter(Boolean).join('\n');
    $('extractedIdentity').hidden=!identity;$('extractedIdentity').textContent=identity;
  }else{$('candidateHint').textContent='Ручной ввод: укажите действительную цену и условия с открытой страницы.';$('extractedIdentity').hidden=true;}
  $('identityConfirmed').checked=false;
}
function renderCapture(data){
  capture=data;selectedCandidate=null;$('capturePanel').hidden=true;$('discoveryPanel').hidden=true;
  if(data.blocked){status('Страница показывает CAPTCHA или ограничение доступа. Сбор остановлен. Можно отметить задание как недоступное; обходов нет.','error');return;}
  if(data.mode==='discovery'){
    $('discoveryPanel').hidden=false;const list=$('discoveryLinks');list.replaceChildren();
    for(const link of data.links||[]){const button=document.createElement('button');button.type='button';const title=document.createElement('span');title.textContent=link.title;const url=document.createElement('small');url.textContent=link.url;button.append(title,url);button.addEventListener('click',()=>run(async()=>{await message('OPEN_PRODUCT',{url:link.url});status('Карточка открыта. Нажмите расширение на новой вкладке и считайте её.');}));list.append(button);}
    status(data.links?.length?`Найдено ${data.links.length} видимых ссылок. Выберите карточку; данные товаров ещё не собирались.`:'В текущем DOM нет видимых ссылок на карточки. Дождитесь загрузки страницы и повторите нажатие.');return;
  }
  $('capturePanel').hidden=false;$('captureInfo').textContent=`${data.title}\n${data.url}\nНаблюдение: ${new Date(data.captured_at).toLocaleString('ru-RU')}`;
  $('observationForm').reset();$('sellerName').disabled=false;$('sellerId').disabled=false;$('sellerName').required=true;$('sellerId').required=false;$('observationPermission').value=currentState?.job?.permission_reference||currentState?.settings.permissionReference||'';
  const select=$('candidate');select.replaceChildren(new Option('Ввести цену вручную',''));
  data.candidates.forEach((candidate,index)=>select.add(new Option(`${candidate.price.toLocaleString('ru-RU')} ${candidate.currency} · ${candidate.method==='jsonld'?'JSON-LD Offer':'DOM'}${candidate.seller_name?` · ${candidate.seller_name}`:''}`,String(index))));
  const primary=data.candidates.findIndex(candidate=>candidate.method==='jsonld'&&candidate.currency==='RUB');if(primary>=0)select.value=String(primary);selectCandidate();
  if(currentState?.job&&parser.marketplacePage(currentState.job.url).url===data.url){$('productId').value=currentState.job.product_id;$('useJob').checked=true;}
  renderCanonical();$('useJobLabel').hidden=!currentState?.job;
  status(data.candidates.length?`Найдено ${data.candidates.length} вариантов цены. Приоритет — конкретный JSON-LD Offer; низкая цена по карте не считается обычной автоматически. Проверьте поля и подтвердите отправку.`:'Цена не найдена автоматически. Введите её с экрана вручную; неизвестные данные не подставляются.');
}
$('settingsForm').addEventListener('submit',event=>{
  event.preventDefault();let settings,permission;
  try{settings={apiOrigin:parser.apiOrigin($('apiOrigin').value),token:$('token').value.trim(),permissionReference:$('permissionReference').value.trim()};permission=chrome.permissions.request({origins:[`${settings.apiOrigin}/*`]});}catch(error){status(error.message,'error');return;}
  run(async()=>{if(!await permission)throw new Error('Доступ к вашему API не разрешён. Настройки не сохранены.');renderState(await message('SAVE_SETTINGS',{settings}));status('Настройки сохранены. Доступ выдан только вашему API; данные страницы не отправлялись.','success');});
});
$('reset').addEventListener('click',()=>run(async()=>{renderState(await message('RESET'));products=[];capture=null;renderProducts();$('capturePanel').hidden=true;$('discoveryPanel').hidden=true;status('Ключ, задание и разрешения API удалены.','success');}));
$('loadCatalog').addEventListener('click',()=>run(async()=>{const config=await message('API_CONFIG');if(!config.enabled)throw new Error('Сборщик отключён на сервере.');const result=await message('CATALOG');products=result.items||[];if(currentState?.job&&!products.some(product=>product.id===currentState.job.product_id))products.push({...currentState.job.product,id:currentState.job.product_id});renderProducts();status(`Загружено ${products.length} моделей. Отсутствующую модель сначала добавьте через админку.`,'success');}));
$('capture').addEventListener('click',()=>run(async()=>renderCapture(await message('CAPTURE'))));
$('claimJob').addEventListener('click',()=>run(async()=>{const result=await message('CLAIM_JOB');renderState(await message('GET_STATE'));$('queuePanel').open=true;status(result.job?'Задание получено. Откройте его отдельной кнопкой, дождитесь страницы и снова нажмите расширение.':'Очередь пуста. Задания добавляются в админке.');}));
$('openJob').addEventListener('click',()=>run(async()=>{await message('OPEN_JOB');status('Открыта вкладка задания. Для чтения нажмите расширение на этой вкладке.');}));
$('failJob').addEventListener('click',()=>run(async()=>{await message('FAIL_JOB',{error:capture?.blocked?'captcha_or_block':'extraction_unavailable'});renderState(await message('GET_STATE'));status('Задание отмечено как недоступное. Фоновая повторная попытка не выполняется.','success');}));
$('productId').addEventListener('change',renderCanonical);$('candidate').addEventListener('change',selectCandidate);
$('sellerUnknown').addEventListener('change',()=>{const unknown=$('sellerUnknown').checked;for(const id of ['sellerName','sellerId']){$(id).disabled=unknown;$(id).required=id==='sellerName'&&!unknown;}$('identityConfirmed').checked=false;});
for(const id of ['price','currency','priceType','paymentCondition','region','availability','condition','sellerName','sellerId','warranty','observationPermission'])$(id).addEventListener('input',()=>$('identityConfirmed').checked=false);
$('exportLinks').addEventListener('click',()=>{if(!capture?.links)return;const blob=new Blob([JSON.stringify({category_url:capture.url,captured_at:capture.captured_at,links:capture.links},null,2)],{type:'application/json'});const url=URL.createObjectURL(blob),anchor=document.createElement('a');anchor.href=url;anchor.download='cenoskop-product-links.json';anchor.click();setTimeout(()=>URL.revokeObjectURL(url),2000);});
$('observationForm').addEventListener('submit',event=>{event.preventDefault();run(async()=>{
  if(!capture||capture.blocked||capture.mode!=='product')throw new Error('Сначала считайте открытую карточку товара.');
  const product=products.find(item=>item.id===$('productId').value);if(!product)throw new Error('Выберите каноническую модель.');
  if(!$('identityConfirmed').checked)throw new Error('Подтвердите точное совпадение модели и условий.');
  if(product.condition!==$('condition').value)throw new Error('Состояние товара не совпадает с канонической моделью. Выберите другую модель.');
  const price=parser.parsePrice($('price').value);if(price===null)throw new Error('Укажите корректную цену.');
  if($('priceType').value==='regular'&&!['any_card','other_bank_card'].includes($('paymentCondition').value))throw new Error('Цена с условием карты площадки / кошелька / рассрочки требует отдельного типа. Исправьте тип цены.');
  const method=selectedCandidate&&price===selectedCandidate.price&&$('currency').value===selectedCandidate.currency?selectedCandidate.method:'manual';
  const observation={product_id:product.id,page_url:capture.url,captured_at:capture.captured_at,permission_reference:$('observationPermission').value.trim(),extraction_method:method,identity_confirmed:true,price,currency:$('currency').value,region:$('region').value.trim(),price_type:$('priceType').value,payment_condition:$('paymentCondition').value,availability:$('availability').value==='true',condition:$('condition').value,seller_id:$('sellerUnknown').checked?null:($('sellerId').value.trim()||null),seller_name:$('sellerUnknown').checked?null:($('sellerName').value.trim()||null),extracted_price_text:(selectedCandidate?.raw||$('price').value).slice(0,120),extractor_version:capture.extractor_version};
  if($('warranty').value!=='')observation.warranty_months=Number($('warranty').value);
  const result=await message('SUBMIT_OBSERVATION',{observation,useJob:$('useJob').checked});renderState(await message('GET_STATE'));$('identityConfirmed').checked=false;
  status(`Сохранено: ${result.imported??0}, повторов: ${result.duplicates??0}. ${result.job_status==='completed'?'Задание завершено.':''} Источник и условия зафиксированы.`,'success');
});});
message('GET_STATE').then(renderState).catch(error=>status(error.message,'error'));

'use strict';
importScripts('extractor.js');
const STORAGE_SETTINGS='collectorSettings',STORAGE_WORKER='collectorWorkerId',STORAGE_JOB='collectorJob';
const extractor=globalThis.CenoskopExtractor;
chrome.storage.local.setAccessLevel?.({accessLevel:'TRUSTED_CONTEXTS'}).catch(()=>{});

async function state(){
  const stored=await chrome.storage.local.get([STORAGE_SETTINGS,STORAGE_WORKER,STORAGE_JOB]);
  if(!stored[STORAGE_WORKER]){stored[STORAGE_WORKER]=crypto.randomUUID();await chrome.storage.local.set({[STORAGE_WORKER]:stored[STORAGE_WORKER]});}
  return {settings:stored[STORAGE_SETTINGS]||{apiOrigin:'http://localhost:8000',token:'',permissionReference:''},worker_id:stored[STORAGE_WORKER],job:stored[STORAGE_JOB]||null};
}
async function api(path,method='GET',body){
  const current=await state();const origin=extractor.apiOrigin(current.settings.apiOrigin);
  if(!current.settings.token)throw new Error('Сначала сохраните COLLECTOR_TOKEN в настройках.');
  if(!await chrome.permissions.contains({origins:[`${origin}/*`]}))throw new Error('Нет доступа к вашему API. Нажмите «Сохранить и разрешить API».');
  let response;
  try{response=await fetch(`${origin}${path}`,{method,headers:{Authorization:`Bearer ${current.settings.token}`,...(body?{'Content-Type':'application/json'}:{})},...(body?{body:JSON.stringify(body)}:{}),credentials:'omit',redirect:'error',cache:'no-store',signal:AbortSignal.timeout(20000)});}catch{throw new Error('Не удалось подключиться к API. Проверьте адрес и запуск сервера. Перенаправления API не разрешены.');}
  const data=await response.json().catch(()=>null);
  if(!response.ok){const detail=typeof data?.detail==='string'?data.detail:JSON.stringify(data?.detail||'Ошибка API');throw new Error(`${response.status}: ${detail}`);}
  return data;
}
async function dispatch(message){
  if(!message||typeof message.type!=='string')throw new Error('Некорректная команда.');
  if(message.type==='GET_STATE')return state();
  if(message.type==='SAVE_SETTINGS'){
    const settings={apiOrigin:extractor.apiOrigin(message.settings?.apiOrigin),token:String(message.settings?.token||'').trim(),permissionReference:String(message.settings?.permissionReference||'').trim()};
    if(settings.token.length<16||settings.token.length>1000)throw new Error('COLLECTOR_TOKEN должен содержать от 16 до 1000 символов.');
    if(settings.permissionReference.length<8||settings.permissionReference.length>500)throw new Error('Укажите разрешение / договор от 8 до 500 символов.');
    if(!await chrome.permissions.contains({origins:[`${settings.apiOrigin}/*`]}))throw new Error('Разрешение доступа к API не выдано.');
    const previous=(await state()).settings;
    await chrome.storage.local.set({[STORAGE_SETTINGS]:settings});
    if(previous.apiOrigin!==settings.apiOrigin){await chrome.storage.local.remove(STORAGE_JOB);try{await chrome.permissions.remove({origins:[`${previous.apiOrigin}/*`]});}catch{/* Previous optional grant may be absent. */}}
    return state();
  }
  if(message.type==='RESET'){
    const permissions=await chrome.permissions.getAll();if(permissions.origins?.length)await chrome.permissions.remove({origins:permissions.origins});
    await chrome.storage.local.remove([STORAGE_SETTINGS,STORAGE_JOB]);return state();
  }
  if(message.type==='API_CONFIG')return api('/api/collector/config');
  if(message.type==='CATALOG')return api('/api/collector/products');
  if(message.type==='CLAIM_JOB'){
    const current=await state();
    if(current.job&&Date.parse(current.job.lease_expires_at)>Date.now())return {job:current.job};
    const result=await api('/api/collector/jobs/claim','POST',{worker_id:current.worker_id});
    if(result.job){extractor.marketplacePage(result.job.url);await chrome.storage.local.set({[STORAGE_JOB]:result.job});}else await chrome.storage.local.remove(STORAGE_JOB);
    return result;
  }
  if(message.type==='OPEN_JOB'){
    const {job}=await state();if(!job)throw new Error('Сначала получите задание.');
    if(Date.parse(job.lease_expires_at)<=Date.now())throw new Error('Аренда задания истекла. Получите его заново.');
    const page=extractor.marketplacePage(job.url);await chrome.tabs.create({url:page.url,active:true});return {opened:true};
  }
  if(message.type==='OPEN_PRODUCT'){const page=extractor.marketplacePage(message.url);await chrome.tabs.create({url:page.url,active:true});return {opened:true};}
  if(message.type==='CAPTURE'){
    const [tab]=await chrome.tabs.query({active:true,currentWindow:true});
    if(!tab?.id||!tab.url)throw new Error('Откройте карточку товара и нажмите значок расширения на этой вкладке.');
    extractor.supportedPage(tab.url);
    await chrome.scripting.executeScript({target:{tabId:tab.id},files:['extractor.js']});
    const results=await chrome.scripting.executeScript({target:{tabId:tab.id},func:()=>globalThis.CenoskopExtractor.extract(document,location.href)});
    if(!results[0]?.result)throw new Error('Не удалось прочитать страницу. Дождитесь её загрузки и повторите действие.');
    return results[0].result;
  }
  if(message.type==='FAIL_JOB'){
    const current=await state();if(!current.job)throw new Error('Нет активного задания.');
    const result=await api(`/api/collector/jobs/${encodeURIComponent(current.job.id)}/fail`,'POST',{worker_id:current.worker_id,lease_token:current.job.lease_token,error:String(message.error||'manual_unavailable').slice(0,500)});
    await chrome.storage.local.remove(STORAGE_JOB);return result;
  }
  if(message.type==='SUBMIT_OBSERVATION'){
    const current=await state(),observation=message.observation;
    if(!observation||observation.identity_confirmed!==true)throw new Error('Подтвердите точное совпадение модели и условий.');
    const page=extractor.marketplacePage(observation.page_url);
    const payload={...observation,page_url:page.url,worker_id:current.worker_id};
    if(message.useJob){
      const job=current.job;if(!job||Date.parse(job.lease_expires_at)<=Date.now())throw new Error('Нет действующей аренды задания. Получите задание заново.');
      if(page.url!==extractor.marketplacePage(job.url).url||payload.product_id!==job.product_id)throw new Error('Открытая карточка или модель не соответствует заданию.');
      payload.job_id=job.id;payload.lease_token=job.lease_token;payload.permission_reference=job.permission_reference;
    }
    const result=await api('/api/collector/observations','POST',payload);
    if(message.useJob)await chrome.storage.local.remove(STORAGE_JOB);return result;
  }
  throw new Error('Команда не поддерживается.');
}
chrome.runtime.onMessage.addListener((message,sender,sendResponse)=>{
  if(sender.id!==chrome.runtime.id||sender.tab){sendResponse({ok:false,error:'Доступно только из окна расширения.'});return false;}
  dispatch(message).then(data=>sendResponse({ok:true,data})).catch(error=>sendResponse({ok:false,error:error instanceof Error?error.message:'Неизвестная ошибка'}));return true;
});
